"""Synthetic parser example."""
