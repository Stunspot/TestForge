"""Synthetic reporting example."""
